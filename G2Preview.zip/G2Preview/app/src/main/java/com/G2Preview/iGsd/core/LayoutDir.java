
package com.G2Preview.iGsd.core;


public enum LayoutDir{ LTR, RTL }

